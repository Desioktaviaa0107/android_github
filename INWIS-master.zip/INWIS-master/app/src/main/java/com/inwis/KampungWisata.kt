package com.inwis

data class KampungWisata (
    var kampung_wisata: String = "",
    var img : Int = 0
)

